A BIG thanks to:
	Mino for animating the dash, jump, and oblobble riding movement as well as the bombs.
	Mola for drawing the pale lurker statue and Dung Defender pillars.
	56, KDT, Sid, and everyone in #modding for helping as always.
	Zaliant for making the music.
	Sumwan for helping with the text.
	Procrastination for causing me to take 7 months on this mod.
	Cranky Templar/Zaliant/Jngo102 for testing the mod for me.

This list is not 100% accurate but I don't feel like fixing it. It should give a general idea of the mod, have fun.
Music
	Separated based on phase
	Done
Animation
	jump
	riding roar
	Dash/backdash
	default riding
	throwing riding
Phase 1
	Digs when attacked, otherwise hops towards player
	Can dig onto wall as well as ground
	If digs out off wall then she should dash across screen and throw projectiles
	Has a chance to use white defender spikes when digging
	Has a chance to air jump towards player, stop midair, and shoot 3 spikes after digging
	If she hops towards a wall, then she wall jumps and shoot spikes
	Barbs move when on ground
	Dash back, shoot dagger to evade attack
	Knightmere: The telegraph between attacks in first phase should be different (tantrum for dig)

Phase 2
	Starts by digging to a wall, spawns spikes on ground
	Throws grenades 3 at a time, the grenades create fire pillars upon hitting ground
	Switches sides a few times and repeats
	Next, she jumps to the middle (after spawning a platform), does an animation that causes enemies to start spawning (primal aspids and other flying enemies). 
	While enemies spawn, she jumps between walls (either with a platform in the middle or by jumping to the ceiling then to the opposite side) and shoots daggers
	Goes on wall and dashes to the other side
	Enemies make formations around player and shoot in order
	When enemy spawn is nearing its end, she shoots wired daggers from different angles of the arena (forming lines horizontally, diagonally, and vertically), saws spawn from these once the enemy spawn ends
	Once enemy spawn is over (determined by health), Colosseum floor moves upward and spikes spawn on the new floor.
	Make her evade obstacles with you while still shooting at you.
	Saws come from left and right
	If player has soul, saws come from both sides at once
	Smoke particle rises from bottom then spreads out on to the screen (saws will not be covered by particles). Pale Champion hides
	Different arrangements of saws spawn, the knight has to dodge for a certain period of time, the arena gets smaller and smaller

Phase 3
	Everything returns to normal (except for the spikes on the ground). An Oblobble spawns as she jumps on to it from above.
	Primal Aspids spawn two at a time during this phase.
	During the Oblobble's cool down, Pale Champion shoots daggers/spikes based on player's position.
